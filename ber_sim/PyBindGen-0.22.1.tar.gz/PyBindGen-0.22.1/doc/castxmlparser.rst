
==========================================================
castxmlparser: scan header files to extract API definitions
==========================================================


.. automodule:: pybindgen.castxmlparser
    :members:
    :undoc-members:
    :show-inheritance:
