.. PyBindGen documentation master file, created by
   sphinx-quickstart on Tue Dec  8 16:06:11 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyBindGen's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 3

   tutorial
   apiref

   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

