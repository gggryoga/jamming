
==================================================
cppexception: translate C++ exceptions into Python
==================================================


.. automodule:: pybindgen.cppexception
    :members:
    :undoc-members:
    :show-inheritance:
