
==========================================================
container: wrap STL containers
==========================================================


.. automodule:: pybindgen.container
    :members:
    :undoc-members:
    :show-inheritance:
