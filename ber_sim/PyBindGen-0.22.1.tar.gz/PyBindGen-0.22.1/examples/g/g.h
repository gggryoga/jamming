
void GDoA (void);

namespace G
{

  void GDoB (void);

  namespace GInner {

    void GDoC (void);

  }

}
