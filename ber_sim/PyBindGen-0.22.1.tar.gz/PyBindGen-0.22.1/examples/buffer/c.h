
unsigned short* GetBuffer();
int  GetBufferLen();
unsigned short  GetBufferChecksum();


